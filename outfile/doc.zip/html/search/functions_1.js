var searchData=
[
  ['getcameramodel_0',['getCameraModel',['../classcom_1_1seevi_1_1SVCameraDevice_1_1SVCameraDevice.html#ae3646b2f52c1b8347333c9fe764fb5a8',1,'com::seevi::SVCameraDevice::SVCameraDevice']]],
  ['getsoftwareversion_1',['getSoftwareVersion',['../classcom_1_1seevi_1_1SVCameraDevice_1_1SVCameraDevice.html#ab37bf390779ce0e0e565bdbe8ccd93be',1,'com::seevi::SVCameraDevice::SVCameraDevice']]]
];
