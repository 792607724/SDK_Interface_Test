var searchData=
[
  ['zoom_0',['Zoom',['../classcom_1_1seevi_1_1SVCameraDevice_1_1SVCameraDevice.html#a2c8a271f6007cac8bf7b4cafeac1bf0a',1,'com::seevi::SVCameraDevice::SVCameraDevice']]]
];
